import React from 'react'
import './App.css';
import CardComponent from './component/CardComponent.js'
import FooterMain from './component/Footer.js';
import Header from './component/Header.js';
import I18n from './i18n';
import { BrowserRouter as Router } from "react-router-dom";
import { Grid } from '@material-ui/core';


function App() {
  let description = 'Customer portal provides services that cater to the customers';
  return (
    <Router>

      <Grid xs={12} md={12} lg={12} style={{ background: '#509224' }}>
        <main style={{ position: 'relative', height: '945px', marginTop: '-164px', background: '#509224' }}>
          <Header />
          <CardComponent name={I18n.t('customer_portal')} description={description} />
        </main>
        <FooterMain />
      </Grid >
    </Router>

  );
}

export default App;
