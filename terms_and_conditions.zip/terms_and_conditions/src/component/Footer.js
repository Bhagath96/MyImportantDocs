import React from 'react'
import { Grid, makeStyles } from '@material-ui/core';
import logo from '../images/Logo.png';
import i18n from '../i18n';


const useStyles = makeStyles({
    root: {
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: 'whitesmoke',
        height: '680px'
    },
    footerContainer: {
        flex: 1,
        display: 'flex',
        flexWrap: 'wrap',
        padding: '20px',
        backgroundColor: '#2689ed',
        height: '450px',
        clipPath: 'polygon(0% 0%,19% 5%,100% 26%,100% 100%,0% 100%)'
    },
    logoContainer: {
        padding: '15px',
        marginTop: '100px',

    },
    logo: {
        objectFit: 'contain',
        width: '137px',
        height: '127px',

        margin: '0 auto',
        marginBottom: '20px'
    },
    para: {
        color: '#fff',
        fontSize: '14px',
        lineHeight: '16px',
        letterSpacing: '2px'
    },
    serviceContainer: {
        padding: '15px',
        paddingTop: '117px',

    },
    copyRight: {
        backgroundColor: '#252525',
        textAlign: 'center',
        height: '80px',
        fontSize: 'var(--text-sub)',
        padding: '',
        color: 'white',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
    },
    copyRightTxt: {
    },
    ul: {
        paddingLeft: '0'
    },
    li: {
        marginBottom: '25px',
        listStyle: 'none'
    },
    a: {
        color: '#fff',
        textTransform: 'uppercase',
        letterSpacing: '1.11px',
        fontWeight: '500',
        fontSize: '14px',
        textDecoration: 'none',
        backgroundColor: 'transparent'
    },
    gridContainer: {
        marginTop: '50px'
    },
    container: {
        height: '100Px'
    },
    h3: {
        color: '#fff',
        wordWrap: 'break-word',
        textTransform: 'uppercase',
        margin: '24px 0',
        fontWeight: '700',
        fontSize: '32px'
    }

})
export default function FooterMain() {
    const classes = useStyles()
    return (
        <div className={classes.root}>
            <div className={classes.footerContainer}>
                <Grid item xs={5} sm={8} md={8} className={classes.logoContainer}>
                    <img className={classes.logo} src={logo} alt='logo' />
                    <h3 className={classes.h3}>{i18n.t('my_beautiful_city')} </h3>
                    <p className={classes.para}>
                        {i18n.t('my_beautiful_city')}
                    </p>
                </Grid>
                <Grid item xs={7} sm={4} md={4}  >
                    <Grid container className={classes.gridContainer}>
                        <Grid item xs={3} md={4} lg={3} className={classes.logoContainer} >
                            <ul className={classes.ul}>
                                <li className={classes.li}>
                                    <a className={classes.a} href='_blank'>{i18n.t('home')}</a>
                                </li>
                                <li className={classes.li}>
                                    <a className={classes.a} href='http://www.v4Websites.com'>{i18n.t('about')}</a>
                                </li>
                                <li className={classes.li}>
                                    <a className={classes.a} href='http://www.v4Websites.com'>{i18n.t('activity')}</a>
                                </li>
                            </ul>
                        </Grid>
                        <Grid item xs={3} md={4} lg={3} className={classes.logoContainer}>
                            <ul className={classes.ul}>
                                <li className={classes.li}>
                                    <a className={classes.a} href='_blank'>{i18n.t('news')}</a>
                                </li>
                                <li className={classes.li}>
                                    <a className={classes.a} href='http://www.v4Websites.com'>{i18n.t('contact_as')}</a>
                                </li>
                                <li className={classes.li}>
                                    <a className={classes.a} href='http://www.v4Websites.com'>{i18n.t('faq')}</a>
                                </li>
                            </ul>
                        </Grid>
                        <Grid item xs={6} md={4} lg={3} className={classes.logoContainer} >
                            <ul className={classes.ul}>
                                <li className={classes.li}>
                                    <a className={classes.a} href='_blank'>{i18n.t('privacy_policy')}</a>
                                </li>
                            </ul>
                        </Grid>
                    </Grid>

                </Grid>
            </div >
            <div className={classes.copyRight}>
                <p className={classes.copyRightTxt}>Copyright © 2021 BHAG.</p>
            </div >

        </div >
    );
};