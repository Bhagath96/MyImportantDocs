import React, { useEffect, useState, useRef } from "react";
import { Grid, makeStyles, ButtonGroup, Button } from '@material-ui/core';
import logo from '../images/Logo.png';
import I18n from '../i18n';

const useStyles = makeStyles({
    root: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        background: '#509224',
        position: 'sticky',
        top: '0',
        width: '100%',
        zIndex: '99'
    },

    alignment: {
        marginTop: '20px'
    },
    header: {
        padding: '10px 16px',
        background: '#555',
        color: ' #f1f1f1'
    },

    content: {
        padding: '16px'
    },

    sticky: {
        background: '#fff',
        position: 'sticky',
        top: '0',
        width: '100%'
    },
    sticky____root: {
        paddingTop: '102px'
    }
});
export default function Header() {

    var header = {};
    var sticky = {};
    useEffect(() => {
        window.onscroll = function () { myFunction() };
        header = window.document.getElementById("myHeader");
        sticky = header.offsetTop;
    }, [window.pageYOffset])

    function myFunction() {
        console.log('sticky', sticky)
        console.log('window.pageYOffset', window.pageYOffset)
        if (window.pageYOffset > 45) {
            console.log('sticky')
            header.classList.add(classes.sticky);
        } else {
            header.classList.remove(classes.sticky);
            header.classList.add(classes.root);

        }
    }

    let setDefaultLanguage = {};
    let Language = 'en-IN';
    setDefaultLanguage.id = 1;
    setDefaultLanguage.locale = Language;
    setDefaultLanguage.state = true;
    const classes = useStyles()
    let selectedLanguage = JSON.parse(localStorage.getItem('selectedLanguage')) || setDefaultLanguage;
    const [checked, setChecked] = useState(selectedLanguage.state);
    const [selectedBtn, setSelectedBtn] = React.useState(1);


    useEffect(() => {
        if (selectedBtn === 2) {
            Language = 'ml-IN';
            setDefaultLanguage.id = 2;
            setDefaultLanguage.locale = Language;
            setDefaultLanguage.state = false;
        }
        else {
            Language = 'en-IN';
            setDefaultLanguage.id = 1;
            setDefaultLanguage.locale = Language;
            setDefaultLanguage.state = true;
        }
        localStorage.setItem('selectedLanguage', JSON.stringify(setDefaultLanguage));
        I18n.changeLanguage(Language);
    }, [selectedBtn])

    return (

        <div container className={classes.root} id='myHeader'>
            <Grid item xs={6} sm={8} md={10} className={classes.alignment} >
                <img style={{
                    width: '100px',
                    height: '125px',
                    objectFit: 'contain',
                    marginLeft: '30px',
                    marginBottom: '20px'
                }} src={logo} alt='logo' />
            </Grid>
            <Grid item xs={6} sm={4} md={2} className={classes.alignment}>

                <ButtonGroup disableElevation variant="contained" color="primary">
                    <Button color={selectedBtn === 1 ? "secondary" : "primary"} onClick={() => setSelectedBtn(1)}>English</Button>
                    <Button color={selectedBtn === 2 ? "secondary" : "primary"} onClick={() => setSelectedBtn(2)}>Malayalam</Button>
                </ButtonGroup>

            </Grid>

        </div>

    );

};