import { PersonOutline } from '@material-ui/icons'
export { PersonOutline }
