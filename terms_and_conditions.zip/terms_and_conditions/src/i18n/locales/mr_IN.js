/* eslint-disable camelcase */
const mrIn = {
    customer_portal: 'aaaaaaaaaaaaaaaaa'
};
export default mrIn;