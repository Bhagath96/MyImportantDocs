/* eslint-disable camelcase */
const enIn = {
    customer_portal: 'Customer Portal',
    my_beautiful_city: 'MY CITY BEAUTIFUL CITY',

};
export default enIn;