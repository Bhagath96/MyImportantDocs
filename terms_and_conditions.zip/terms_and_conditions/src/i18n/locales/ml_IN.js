/* eslint-disable camelcase */
const mlIn = {
    customer_portal: 'malayalam'
};
export default mlIn;