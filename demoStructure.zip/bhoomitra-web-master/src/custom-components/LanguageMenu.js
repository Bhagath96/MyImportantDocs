import React from 'react';
import { useSelector, useDispatch } from "react-redux";
import { makeStyles, Avatar, IconButton, MenuItem, Menu } from '../common/Components';
import { green as deepGreen } from '@material-ui/core/colors';
import { setLanguage } from 'redux-i18n';
import { LANGUAGES, I18N_REDUCER_KEY } from '../i18n/constants';

export default function SimpleMenu() {
    const dispatch = useDispatch();
    const i18Info = useSelector(state => state[I18N_REDUCER_KEY]);
    const classes = useStyles();
    const [anchorEl, setAnchorEl] = React.useState(null);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleChangeLanguages = (event) => {
        dispatch(setLanguage(event))
    }

    return (
        <div>
            <IconButton color="inherit" onClick={handleClick}>
                <Avatar variant="rounded" className={classes.rounded}>{i18Info.lang}</Avatar>
            </IconButton>
            <Menu
                id="simple-menu"
                anchorEl={anchorEl}
                keepMounted
                open={Boolean(anchorEl)}
                onClose={handleClose}
            >
                <MenuItem onClick={() => { handleChangeLanguages(LANGUAGES.EN.language); handleClose(); }}>English</MenuItem>
                <MenuItem onClick={() => { handleChangeLanguages(LANGUAGES.ML.language); handleClose(); }}>Malayalam</MenuItem>
            </Menu>
        </div >
    );
}

const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex',
        '& > *': {
            margin: theme.spacing(1),
        },
    },
    rounded: {
        color: '#fff',
        backgroundColor: deepGreen[500],
    },
}));