const config = {
    apiServer: {
        // url: 'http://localhost',
        url: 'http://192.168.18.193:5000',
        isCentralEnabled: false
    }
}

export default config;
