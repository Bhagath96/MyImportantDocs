import en from './locales/en.js';
import ml from './locales/ml.js';

export const translations = {
    "en": en,
    "ml": ml
}