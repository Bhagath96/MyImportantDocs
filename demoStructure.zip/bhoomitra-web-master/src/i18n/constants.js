const I18N_REDUCER_KEY = 'i18nState';

const LANGUAGES = {
    EN: {
        language: 'en',
        name: "English"
    },
    ML: {
        language: 'ml',
        name: "Malayalam"
    }
}

export { I18N_REDUCER_KEY, LANGUAGES }