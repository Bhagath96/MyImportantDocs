const language = {
    "Welcome": "Welcome",
}

export default language;