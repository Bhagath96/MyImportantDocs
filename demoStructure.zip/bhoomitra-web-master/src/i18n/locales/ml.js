const language = {
    "Welcome": "സ്വാഗതം",
}

export default language;