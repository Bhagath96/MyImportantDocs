import { combineReducers } from 'redux';
import { reducer as form } from 'redux-form';
import notifications from 'react-redux-notify';
import _ from 'lodash';
import * as modules from '../modules';
// import { types } from '../modules/user/actions';
import { i18nState } from "redux-i18n";

// const { LOGOUT_API_REQUEST } = types;

const reducers = {
  form,
  notifications,
  i18nState
};

_.values(modules).forEach(module => {
  if (module.STATE_REDUCER_KEY && module.reducer) {
    reducers[module.STATE_REDUCER_KEY] = module.reducer;
  }
});

const appReducer = combineReducers({
  ...reducers
});

const rootReducer = (state, action) => appReducer(state, action);

export default rootReducer;
