import { persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage'; // defaults to localStorage for web

import rootReducer from './rootReducer';

const persistConfig = {
    key: 'root',
    storage,
    whitelist: ['user'] // only user node needs to be persisted
}

const persistedReducer = persistReducer(persistConfig, rootReducer)

export default persistedReducer;
