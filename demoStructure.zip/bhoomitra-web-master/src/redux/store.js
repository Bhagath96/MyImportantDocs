import { createStore, applyMiddleware } from 'redux';
import createSagaMiddleware, { END } from 'redux-saga';
import { logger } from 'redux-logger';
import { persistStore } from 'redux-persist';

import persistedReducer from './persistedReducer';

const sagaMiddleware = createSagaMiddleware();

const store = createStore(
    persistedReducer,
    {},
    applyMiddleware(sagaMiddleware, logger),
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);

store.runSaga = sagaMiddleware.run;
store.close = () => store.dispatch(END);

const persistor = persistStore(store);

export { store, persistor };