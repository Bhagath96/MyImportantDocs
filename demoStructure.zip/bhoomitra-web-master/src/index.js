import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import App from './layouts/App';
import history from './common/history';
import { store, persistor, rootSaga } from './redux';
import { Notify } from 'react-redux-notify';
import 'react-redux-notify/dist/ReactReduxNotify.css';
import { ThemeProvider } from '@material-ui/styles'
import theme from './common/theme';
import I18n from "redux-i18n";
import {Router } from "react-router-dom";
import { translations } from "./i18n/translations.js";

store.runSaga(rootSaga);


ReactDOM.render(
  // <React.StrictMode>
  <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <I18n translations={translations} initialLang="ml" fallbackLang="en">
        <ThemeProvider theme={theme}>
          <Router history={history}>
            <App />
          </Router>
        </ThemeProvider>
        <Notify />
      </I18n>
    </PersistGate>
  </Provider>
  //  </React.StrictMode>
  , document.getElementById('root')
);
