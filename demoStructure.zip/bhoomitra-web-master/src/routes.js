// import IconDashboard from '@material-ui/icons/Dashboard';
import IconBarChart from '@material-ui/icons/BarChart';
import IconLibraryBooks from '@material-ui/icons/LibraryBooks';
import { Dashboard } from './modules/dashboard/containers';
import { Test } from './modules/test/containers';

export const menuItems = [
    {
        name: 'Test',
        Icon: IconBarChart,
        link: '/',
    },
    {
        name: 'Nested Pages',
        Icon: IconLibraryBooks,
        items: [
            {
                name: 'Level 1',
                Icon: IconBarChart,
                link: '/',
            }
        ],
    }
];

export const PROJECT_MODULE_KEYS = {
    TEST: 'TEST',
    DASHBOARD: 'DASHBOARD'
}

export const ROUTES = {
    [PROJECT_MODULE_KEYS.TEST]: Test,
    [PROJECT_MODULE_KEYS.DASHBOARD]: Dashboard
}
