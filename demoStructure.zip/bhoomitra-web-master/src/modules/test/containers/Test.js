import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import { createStructuredSelector } from 'reselect';
import TestView from '../components/TestView';
import { getSetUserDataInfo } from '../selectors';
import * as DashboardActions from '../actions';

class Dashboard extends Component {
    render() {
        return (<TestView {...this.props} />);
    }
}

const mapStateToProps = createStructuredSelector({
    setUserDataInfo: getSetUserDataInfo
});

const mapDispatchToProps = dispatch => ({
    loadUserData: (data) => dispatch(DashboardActions.loadUserData(data)),
    deleteUserDataInfo: (data) => dispatch(DashboardActions.deleteUserDataInfo(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({
    form: "dashboardForm",
})(Dashboard));