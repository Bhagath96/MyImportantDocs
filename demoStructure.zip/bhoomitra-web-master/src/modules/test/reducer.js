import { types as ActionTypes } from './actions';

const initialState = {
    test: {},
    setUserInfo: {
        refreshing: false,
        // data: undefined
    },
    setUserDataInfo: {
        refreshing: false,
        data: []
    }
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case ActionTypes.SET_USERINFO:
            return Object.assign({}, state, {
                setUserInfo: {
                    refreshing: true,
                    // data: action.payload.data || []
                }
            });
        case ActionTypes.SAVE_USERINFO_SUCCESS:
            return Object.assign({}, state, {
                setUserInfo: {
                    refreshing: false,
                    // data: action.payload.data || []
                }
            });
        case ActionTypes.SET_USER_DATA_INFO:
            return Object.assign({}, state, {
                setUserDataInfo: {
                    refreshing: false,
                    data: action.payload.data.notes || []
                }
            });
        default:
            return state;
    }
}

export default reducer;
