import { takeLatest, all, fork, put, take } from 'redux-saga/effects';
import { types as ActionTypes } from './actions';
import * as Actions from './actions';
import { saga } from '../../common';
import * as API from './api';
import _ from 'lodash';

function* loadUserData(action) {
    yield fork(saga.handleAPIRequest, API.loadUserInfo, action.payload.data);
    const loadUserDataSuccessAction = yield take(ActionTypes.LOAD_USERINFO_SUCCESS);
    yield put(Actions.setUserDataInfo(loadUserDataSuccessAction.payload.data));
}

function* deleteUserRegData(action) {
    if(!_.isEmpty(action.payload.data)){
        const deleteId = action.payload.data.map((val) => val);
        yield fork(saga.handleAPIRequest, API.deleteUserInfo, deleteId);
        const delUserDataSuccessAction = yield take(ActionTypes.DELETE_USER_REG_DATA_SUCCESS);
        console.log('deletdata', delUserDataSuccessAction.payload.data);
    }
}

export default function* testSaga() {
    yield all([
        takeLatest(ActionTypes.LOAD_USER_DATA, loadUserData),
        takeLatest(ActionTypes.DELETE_USER_REG_DATA, deleteUserRegData)
    ]);
}