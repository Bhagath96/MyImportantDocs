import { action } from '../../common';

const types = {
    COMMON_LOAD_STATE: 'Test/COMMON_LOAD_STATE',
    COMMON_LOAD_DISTRICT: 'Test/COMMON_LOAD_DISTRICT',
    SAVE_USERINFO: 'Test/SAVE_USERINFO',
    SAVE_USERINFO_SUCCESS: 'Test/SAVE_USERINFO_SUCCESS',
    SAVE_USERINFO_REQUEST: 'Test/SAVE_USERINFO_REQUEST',
    SAVE_USERINFO_FAILED: 'Test/SAVE_USERINFO_FAILED',
    SET_USERINFO: 'Test/SET_USERINFO',
    LOAD_USER_DATA: 'Test/LOAD_USER_DATA',
    LOAD_USERINFO_SUCCESS: 'Test/LOAD_USERINFO_SUCCESS',
    LOAD_USERINFO_REQUEST: 'Test/LOAD_USERINFO_REQUEST',
    LOAD_USERINFO_FAILED: 'Test/LOAD_USERINFO_FAILED',
    SET_USER_DATA_INFO: 'Test/SET_USER_DATA_INFO',
    DELETE_USER_REG_DATA: 'Test/DELETE_USER_REG_DATA',
    DELETE_USER_REG_DATA_SUCCESS: 'Test/DELETE_USER_REG_DATA_SUCCESS',
    DELETE_USER_REG_DATA_REQUEST: 'Test/DELETE_USER_REG_DATA_REQUEST',
    DELETE_USER_REG_DATA_FAILED: 'Test/DELETE_USER_REG_DATA_FAILED',
};

const loadStates = () => action(types.COMMON_LOAD_STATE);

const loadDistricts = data => action(types.COMMON_LOAD_DISTRICT, { data });

const setUserInfo = data => action(types.SET_USERINFO, { data });

const loadUserData = data => action(types.LOAD_USER_DATA, { data });

const setUserDataInfo = data => action(types.SET_USER_DATA_INFO, { data });

const deleteUserDataInfo = data => action(types.DELETE_USER_REG_DATA, { data });

export { types, loadStates, loadDistricts, setUserInfo, loadUserData, setUserDataInfo, deleteUserDataInfo }