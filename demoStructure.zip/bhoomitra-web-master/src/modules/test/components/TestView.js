import React, { useState } from "react";
import { withScriptjs, withGoogleMap, GoogleMap, Marker } from "react-google-maps";
import { compose, withProps } from "recompose";
import { Button, TextField } from '@material-ui/core';

const TestView = (props) => {
  const [textInput, setTextInput] = useState('');
  const [language, setlanguage] = useState('');

  const ChangeGoogleMapsLanguage = () => { 
    setlanguage(textInput) 
 }
  const handleTextInputChange = event => {
    setTextInput(event.target.value);
  };

  const MyMapComponent = compose(
    withProps({
      googleMapURL: `https://maps.googleapis.com/maps/api/js?key=AIzaSyAFDjT6AmeTZNuMXuQw-a-NicyU88k7EOM&callback=initMap&language=${language}`,
      loadingElement: <div style={{ height: `100%` }} />,
      containerElement: <div style={{ height: `400px` }} />,
      mapElement: <div style={{ height: `100%` }} />,
    }),
    withScriptjs,
    withGoogleMap
  )((props) =>
    <GoogleMap
      defaultZoom={8}
      defaultCenter={{ lat: 9.767, lng: 78.871 }}>
      {props.isMarkerShown && <Marker position={{ lat: 9.767, lng: 76.871 }} />}
    </GoogleMap>
  );

  return (
    <div>
      <TextField
        fullWidth
        label='Language'
        placeholder="Enter your language code"
        value={textInput}
        onChange={(val)=>handleTextInputChange(val)}
      />
      <Button color="primary" onClick={() => ChangeGoogleMapsLanguage()}>Change Language</Button>
      <MyMapComponent isMarkerShown />
    </div>

  );
}

export default TestView;