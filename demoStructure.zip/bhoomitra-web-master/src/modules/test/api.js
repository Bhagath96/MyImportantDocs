import { restAPI, URL } from '../../common';
import { types as ActionTypes } from './actions';


export function loadDistricts({ types, body }) {
    let payload = {
        types,
        body
    };
    return {
        url: URL.COMMON.LOAD_DISTRICTS,
        api: restAPI.post,
        payload,
    };
}

export function loadUserInfo() {
    let payload = {
        types: [ActionTypes.LOAD_USERINFO_REQUEST, ActionTypes.LOAD_USERINFO_SUCCESS, ActionTypes.LOAD_USERINFO_FAILED]
    };
    return {
        url: URL.USER.LOADUSERINFO,
        api: restAPI.get,
        payload,
    };
}

export function deleteUserInfo(deleteId) {
    let payload = {
        types: [ActionTypes.DELETE_USER_REG_DATA_REQUEST, ActionTypes.DELETE_USER_REG_DATA_SUCCESS, ActionTypes.DELETE_USER_REG_DATA_FAILED]
    };
    return {
        url: `${URL.USER.DELETE_USERINFO}/${deleteId}`,
        api: restAPI.del,
        payload,
    };
}