import { STATE_REDUCER_KEY } from './constants';
import flow from 'lodash/fp/flow';

export const getTest = state => state[STATE_REDUCER_KEY];

const setUserDataInfo = testState => testState.setUserDataInfo;
export const getSetUserDataInfo = flow(getTest, setUserDataInfo);