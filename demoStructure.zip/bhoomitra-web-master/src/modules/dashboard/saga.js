import { takeLatest, all, fork, put, delay , take} from 'redux-saga/effects';
import { types as ActionTypes } from './actions';
import * as Actions from './actions';
import { saga, history } from '../../common';
import * as API from './api';

function* saveUserInfo(action) {
    yield delay(100);
    yield fork(saga.handleAPIRequest, API.saveUserInfo, action.payload.data);
    yield put(Actions.setUserInfo());
    history.push('/');
}

function* updateUserInfo(action) {
    console.log('action.payload.data--', action.payload.data);
    yield fork(saga.handleAPIRequest, API.updateUserInfo, action.payload.data);
    const updateUserDataSuccessAction = yield take(ActionTypes.UPDATE_USERINFO_SUCCESS);
    console.log('Udatedata', updateUserDataSuccessAction.payload.data);
    history.push('/');
}

export default function* dashboardSaga() {
    yield all([
        takeLatest(ActionTypes.SAVE_USERINFO, saveUserInfo),
        takeLatest(ActionTypes.UPDATE_USERINFO, updateUserInfo)
    ]);
}