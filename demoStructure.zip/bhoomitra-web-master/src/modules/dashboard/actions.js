import { action } from '../../common';

const types = {
    COMMON_LOAD_STATE: 'Dashboard/COMMON_LOAD_STATE',
    COMMON_LOAD_DISTRICT: 'Dashboard/COMMON_LOAD_DISTRICT',
    SAVE_USERINFO: 'Dashboard/SAVE_USERINFO',
    SAVE_USERINFO_SUCCESS: 'Dashboard/SAVE_USERINFO_SUCCESS',
    SAVE_USERINFO_REQUEST: 'Dashboard/SAVE_USERINFO_REQUEST',
    SAVE_USERINFO_FAILED: 'Dashboard/SAVE_USERINFO_FAILED',
    SET_USERINFO: 'Dashboard/SET_USERINFO',
    UPDATE_USERINFO: 'Dashboard/UPDATE_USERINFO',
    UPDATE_USERINFO_SUCCESS: 'Dashboard/UPDATE_USERINFO_SUCCESS',
    UPDATE_USERINFO_REQUEST: 'Dashboard/UPDATE_USERINFO_REQUEST',
    UPDATE_USERINFO_FAILED: 'Dashboard/UPDATE_USERINFO_FAILED',
};

const loadStates = () => action(types.COMMON_LOAD_STATE);

const loadDistricts = data => action(types.COMMON_LOAD_DISTRICT, { data });

const saveUserInfo = data => action(types.SAVE_USERINFO, { data });

const setUserInfo = data => action(types.SET_USERINFO, { data });

const updateUserInfo = data => action(types.UPDATE_USERINFO, { data });

export { types, loadStates, loadDistricts, saveUserInfo, setUserInfo, updateUserInfo }