import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import { createStructuredSelector } from 'reselect';
import DashboardView from '../components/DashboardView';
import { getDashboard, getSetUserInfo } from '../selectors';
import * as DashboardActions from '../actions';

class Dashboard extends Component {
    render() {
        return (<DashboardView {...this.props} />);
    }
}

const mapStateToProps = createStructuredSelector({
    dashboard: getDashboard,
    setUserInfo: getSetUserInfo
});

const mapDispatchToProps = dispatch => ({
    saveUserInfo: (data) => dispatch(DashboardActions.saveUserInfo(data)),
    updateUserInfo: (data) => dispatch(DashboardActions.updateUserInfo(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({
    form: "dashboardForm",
})(Dashboard));