import { restAPI, URL } from '../../common';
import { types as ActionTypes } from './actions';


export function loadDistricts({ types, body }) {
    let payload = {
        types,
        body
    };
    return {
        url: URL.COMMON.LOAD_DISTRICTS,
        api: restAPI.post,
        payload,
    };
}

export function saveUserInfo({ types, name, email, password}) {
    let payload = {
        types: [ActionTypes.SAVE_USERINFO_REQUEST, ActionTypes.SAVE_USERINFO_SUCCESS, ActionTypes.SAVE_USERINFO_FAILED],
        body: { name,  email,  password }
    };
    return {
        url: URL.COMMON.SAVE_USERINFO,
        api: restAPI.post,
        payload,
    };
}

export function updateUserInfo({ id, name, email, password}) {
    let payload = {
        types: [ActionTypes.SAVE_USERINFO_REQUEST, ActionTypes.SAVE_USERINFO_SUCCESS, ActionTypes.SAVE_USERINFO_FAILED],
        body: { name,  email,  password }
    };
    return {
        url: `${URL.USER.UPDATE_USERINFO}${id}`,
        api: restAPI.put,
        payload,
    };
}