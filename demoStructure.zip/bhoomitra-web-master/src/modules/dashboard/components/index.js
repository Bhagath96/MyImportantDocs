import DashboardView from './DashboardView';

export {
    DashboardView
};
