import React from 'react'
import { Grid, Paper, Typography, TextField, Button } from '@material-ui/core';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { Formik } from 'formik';
import * as yup from 'yup';

const DashboardView = (props) => {
  const { saveUserInfo } = props;

  const paperStyle = { padding: '30px 20px', width: "1240px", margin: "5px auto" }
  const headerStyle = { margin: 0 }
  const marginTop = { marginTop: 5 }

  const loginValidationSchema = yup.object().shape({
    name: yup
      .string()
      .required('Please enter Name'),
    email: yup
      .string()
      .required('Please enter email'),
    password: yup
      .string()
      .required('Please enter password'),
    acceptTerm: yup
      .string()
      .required('Please accept the term and conditions'),
  });

  return (
    <Formik
      validationSchema={loginValidationSchema}
      initialValues={{ id: '', name: '', email: '', gender: '', password: '', confirmPassword: '', acceptTerm: '' }}
      onSubmit={saveUserInfo}
    >
      {({ handleChange, handleSubmit, values, errors }) => (
        <>
          <Grid>
            <Paper elevation={20} style={paperStyle}>
              <Grid align='center'>
                <h2 style={headerStyle}>Sign Up</h2>
                <Typography variant='caption' gutterBottom>Please fill this form to create an account !</Typography>
              </Grid>
              <form>
                <TextField
                  onChange={handleChange('name')}
                  fullWidth
                  label='Name'
                  placeholder="Enter your name" />
                <Typography variant="h6" style={{ color: 'red', fontStyle: 'italic' }}>{errors.name}</Typography>
                <TextField
                  onChange={handleChange('email')}
                  fullWidth
                  label='Email'
                  placeholder="Enter your email" />
                <Typography variant="h6" style={{ color: 'red', fontStyle: 'italic' }}>{errors.email}</Typography>
                <FormControl component="fieldset" style={marginTop}>
                  <FormLabel component="legend">Gender</FormLabel>
                  <RadioGroup aria-label="gender" name="gender" style={{ display: 'initial' }}>
                    <FormControlLabel value="female" control={<Radio />} label="Female" />
                    <FormControlLabel value="male" control={<Radio />} label="Male" />
                  </RadioGroup>
                </FormControl>
                <TextField
                  onChange={handleChange('phone')}
                  fullWidth label='Phone Number' placeholder="Enter your phone number" />
                <TextField
                  onChange={handleChange('password')}
                  fullWidth label='Password' placeholder="Enter your password" />
                <Typography variant="h6" style={{ color: 'red', fontStyle: 'italic' }}>{errors.password}</Typography>
                <TextField
                  onChange={handleChange('confirmPassword')}
                  fullWidth label='Confirm Password' placeholder="Confirm your password" />
                <FormControlLabel
                  onChange={handleChange('acceptTerm')}
                  control={<Checkbox name="checkedA" />}
                  label="I accept the terms and conditions."
                />
                <Typography variant="h6" style={{ color: 'red', fontStyle: 'italic' }}>{errors.acceptTerm}</Typography>
                <Button
                  onClick={() => handleSubmit()}
                  type='submit'
                  variant='contained'
                  color='primary'>
                  Sign up
                </Button>
              </form>
            </Paper>
          </Grid>
        </>
      )}
    </Formik>
  );
}

export default DashboardView;