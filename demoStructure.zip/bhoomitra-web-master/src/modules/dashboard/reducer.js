import { types as ActionTypes } from './actions';

const initialState = {
    dashboard: {},
    setUserInfo: {
        refreshing: false,
        // data: undefined
    },
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case ActionTypes.SAVE_USERINFO:
            return Object.assign({}, state, {
                setUserInfo: {
                    ...state.saveUserInfo,
                    refreshing: false
                }
            });
        case ActionTypes.SET_USERINFO:
            return Object.assign({}, state, {
                setUserInfo: {
                    refreshing: true,
                    // data: action.payload.data || []
                }
            });
        case ActionTypes.SAVE_USERINFO_SUCCESS:
            return Object.assign({}, state, {
                setUserInfo: {
                    refreshing: false,
                    // data: action.payload.data || []
                }
            });
        default:
            return state;
    }
}

export default reducer;
