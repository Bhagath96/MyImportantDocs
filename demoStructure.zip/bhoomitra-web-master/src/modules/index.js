
import * as dashboard from './dashboard';
import * as test from './test';

export { dashboard, test };
