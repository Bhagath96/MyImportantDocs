import React from 'react';
import clsx from 'clsx';
import { Switch, Route } from 'react-router-dom';
import { makeStyles, CssBaseline, Drawer, Container, Typography, AppBar, Toolbar, Divider, Avatar, IconButton, Badge } from '../common/Components';
import { green as deepGreen } from '@material-ui/core/colors';
import MenuIcon from '@material-ui/icons/Menu';
import NotificationsIcon from '@material-ui/icons/Notifications';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import AppMenu from './AppMenu';
import commonTheme from '../common/theme';
import { LanguageMenu } from '../custom-components';
import { ROUTES, PROJECT_MODULE_KEYS } from '../routes';

const Level1 = () => React.createElement(Typography, { variant: "h3", component: "h1" }, "1 Page");

const App = (props) => {
    const classes = useStyles();
    const [open, setOpen] = React.useState(true);
    const handleDrawerOpen = () => {
        setOpen(true);
    };
    const handleDrawerClose = () => {
        setOpen(false);
    };
    return (
        <div className={clsx('App', classes.root)}>
            <CssBaseline />
            <AppBar position="absolute" className={clsx(classes.appBar, open && classes.appBarShift)}>
                <Toolbar className={classes.toolbar}>
                    <IconButton
                        edge="start"
                        color="inherit"
                        aria-label="open drawer"
                        onClick={handleDrawerOpen}
                        className={clsx(classes.menuButton, open && classes.menuButtonHidden)}
                    >
                        <MenuIcon />
                    </IconButton>
                    {/* <div className={clsx(classes.alignTitles)}>
                        <LanguageMenu />
                        <IconButton color="inherit">
                            <Badge badgeContent={4} color="secondary">
                                <NotificationsIcon />
                            </Badge>
                        </IconButton>
                        <IconButton>
                            <Avatar alt="Trois" src="/broken-image.jpg" className={classes.green} />
                        </IconButton>
                    </div> */}
                </Toolbar>

            </AppBar>
            <Drawer
                variant="permanent"
                classes={{
                    paper: clsx(classes.drawerPaper, commonTheme.sidebar, !open && classes.drawerPaperClose),
                }}
                open={open}
            >
                <div className={classes.toolbarIcon}>
                    <IconButton onClick={handleDrawerClose}>
                        <ChevronLeftIcon />
                    </IconButton>
                </div>
                <Divider />

                <AppMenu />

            </Drawer>
            {/* <AppBar position="absolute" className={clsx(classes.appBar, open && classes.appBarShift, classes.footer)}>
                <Typography variant='h6' className={classes.footer}>
                    © Copyright 2020
                    </Typography>
            </AppBar> */}

            <main className={classes.content}>
                <Container maxWidth="lg" className={classes.container}>
                    <Switch>
                        <Route path="/test" exact component={ROUTES[PROJECT_MODULE_KEYS.DASHBOARD]} />
                        <Route path="/" exact component={ROUTES[PROJECT_MODULE_KEYS.TEST]} />
                        <Route path="/level2" component={Level1} />
                    </Switch>
                </Container>
            </main>

        </div>
    );
}

const useStyles = makeStyles(theme => ({
    titleIcons: {
        flexDirection: 'row'
    },
    root: {
        display: 'flex',
    },
    drawerPaper: {
        position: 'relative',
        whiteSpace: 'nowrap',
        // paddingTop: theme.spacing(4),
        // paddingBottom: theme.spacing(4),
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
        ...commonTheme.sidebar
    },
    drawerPaperClose: {
        overflowX: 'hidden',
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        width: theme.spacing(7),
        [theme.breakpoints.up('sm')]: {
            width: theme.spacing(7), // size of the Colapsed Sidebar
        },
    },
    appBarSpacer: theme.mixins.toolbar,
    content: {
        flexGrow: 1,
        height: '100vh',
        overflow: 'auto',
    },
    container: {
        paddingTop: theme.spacing(10),
        paddingBottom: theme.spacing(10),
    },
    toolbar: {
        paddingRight: 24, // keep right padding when drawer closed
    },
    toolbarIcon: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: '0 8px',
        ...theme.mixins.toolbar,
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        background: commonTheme.sidebar.background,
    },
    appBarShift: {
        marginLeft: commonTheme.sidebar.width,
        width: `calc(100% - ${commonTheme.sidebar.width}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    menuButton: {
        alignSelf: 'flex-end',
        marginRight: 36,
    },
    menuButtonHidden: {
        display: 'none',
    },
    paper: {
        padding: theme.spacing(2),
        display: 'flex',
        overflow: 'auto',
        flexDirection: 'column',
    },
    footer: {
        display: 'inline-flex',
        bottom: 0,
        top: 'auto',
        flex: 1,
        fontSize: 14,
        justifyContent: 'center'
    },
    alignTitles: {
        display: 'inline-flex',
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end'
    },
    green: {
        color: theme.palette.getContrastText(deepGreen[500]),
        backgroundColor: deepGreen[500],
    },
}));
export default App;

