import React from 'react';
import { menuItems } from '../routes';
import AppMenuItem from './AppMenuItem';
import { makeStyles, createStyles, List } from '../common/Components';

const AppMenu = () => {
    const classes = useStyles();
    return (
        <List component="nav" className={classes.appMenu} disablePadding>
            {menuItems.map((item, index) => (
                <AppMenuItem {...item} key={index} />
            ))}
        </List>
    )
}

const useStyles = makeStyles(theme => createStyles({
    appMenu: {
        width: '100%',
    }
}));
export default AppMenu;