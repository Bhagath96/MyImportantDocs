// import _ from 'lodash';
import { put, call, delay } from 'redux-saga/effects';
import action from './action';
// import { types as UserActionTypes } from '../modules/user/actions';
import * as restAPI from './ajax.request';
// import { getUserAuthData } from '../modules/user/selectors';

const oauthTokenBasicHeader = 'Basic XXXXXXXX';
// const nonRestrictedURLs = ['users/signup'];
let refreshTokenInProgress = false;

export function* handleAPIRequest(apiFn, ...requestData) {
    let { api, url, payload } = apiFn(...requestData);
    return yield call(invokeApi, api, url, payload);
}

function* invokeApi(api, url, payload) {
    const types = payload.types ? payload.types : ['REQUEST', 'SUCCESS', 'FAILURE'];

    let authHeaders = {};
    // need to remove comment
    // if (url.indexOf('oauth/token') !== -1) {
    //     authHeaders = { Authorization: oauthTokenBasicHeader }
    // } 
    // else if (!isNonRestrictedURL(url)) {
    //     const authData = {}; //yield select(getUserAuthData);
    //     let bearerToken = authData && authData.access_token ? authData.access_token : null;
    //     if (bearerToken) {
    //         authHeaders = { Authorization: `Bearer ${bearerToken}` }
    //     } else {
    //         window.location.hash = '/auth/login';
    //         return;
    //     }
    // }
    payload.headers = Object.assign({}, payload.headers, authHeaders);
    yield put(action(types[0]));
    yield delay(500);
    const { response, error } = yield call(api, url, payload);

    if (error) {
        let errorCode = error ? error.error_cd : null;
        if (errorCode === 4404) { //token expiry
            yield delay(100);
            if (!refreshTokenInProgress) {
                refreshTokenInProgress = true;
                const { error } = yield call(refreshToken);
                refreshTokenInProgress = false;
                if (error) {
                    yield put(action(types[2], { error: error }));
                    yield delay(100);
                   // yield put(action(UserActionTypes.LOGOUT)); // if refresh token error, logout the user
                    return { error };
                }
            } else {
                while (refreshTokenInProgress) {
                    yield delay(1500);
                }
            }
            return yield call(invokeApi, api, url, payload);
        } else if (errorCode === 4403) { //Invalid token
            // yield put(action(UserActionTypes.LOGOUT)); // if invalid token error, logout the user
            return { error };
        } else {
            yield put(action(types[2], { error: error }));
        }
    } else {
        if (response.error) {
            yield put(action(types[2], { error: response.error }));
        } else {
            yield put(action(types[1], { data: response }));
        }
    }
    return { response, error };
}

function* refreshToken() {
    try {
        const authData = {}//yield select(getUserAuthData);
        let refreshToken = authData && authData.refresh_token ? authData.refresh_token : null;
        let payload = {
            body: { grant_type: 'refresh_token', refresh_token: refreshToken },
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', Authorization: oauthTokenBasicHeader }
        };
        const { response, error } = yield call(restAPI.post, 'oauth/token', payload);
        // if (response) {
        //     yield put(action(UserActionTypes.REFRESH_TOKEN_API_SUCCESS, { data: response }));
        // }
        return { response, error };
    } catch (error) {
        // Skip errors for now
    }
    return { error: { message: 'Unknown error occurred while token refresh' } };
}

// function isNonRestrictedURL(url) {
//     return _.filter(nonRestrictedURLs, function (value) {
//         return url.indexOf(value) !== -1;
//     }).length;
// }
