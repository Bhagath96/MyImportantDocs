import queryString from 'query-string';
import config from '../config';

const requestBodyTypes = ['POST', 'PUT'];

function invoke(method, url, payload) {
    const defaultHeaders = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',

        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "DELETE, POST, GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"
    };
    let reqConfigData = {
        method,
        headers: Object.assign({}, defaultHeaders, payload.headers),
        // credentials: 'include'
    };
    if (requestBodyTypes.indexOf(method) !== -1) {
        reqConfigData.body = reqConfigData.headers['Content-Type'] === 'application/x-www-form-urlencoded'
            ? queryString.stringify(payload.body || {})
            : JSON.stringify(payload.body || {});
    }
    return fetch(`${config.apiServer.url}/${url}`, reqConfigData)
        .then(validateResponse)
        .then(response => ({ response }))
        .catch(handleError);
};

export function post(url, payload) {
    return invoke('POST', url, payload);
}

export function put(url, payload) {
    return invoke('PUT', url, payload);
}

export function del(url, payload) {
    return invoke('DELETE', url, payload);
}

export function get(url, payload) {
    let urlWithParams = payload.params ? `${url}?${queryString.stringify(payload.params)}` : url;
    return invoke('GET', urlWithParams, payload);
}

function validateResponse(response) {
    if (!response.status) {
        return Promise.reject({ message: 'Network unvailable' });
    }
    if (response.status === 401) {
        return Promise.reject({ error_cd: 4401, message: "Username/password does not match." });
    }
    if (response.status === 200) {
        return response.json().then(response => {
            return (response.status_cd && response.status_cd !== 200) ? Promise.reject(response.error) : Promise.resolve(response);
        });
    }
    return Promise.reject({ message: 'HTTP error occured. Status ' + response.status });
}

function handleError(error) {
    if (error instanceof Promise) {
        return error
            .then(function (e) {
                return { error: e };
            }).catch(e => (
                { error: { message: 'Unknown error' } }));
    } else {
        return { error };
    }
}
