export const URL = {
    USER: {
        AUTHENTICATE: 'oauth/token',
        FETCH_USER_INFO: 'users/detail',
        LOGOUT: 'logout',
        LOADUSERINFO: 'users',
        DELETE_USERINFO: 'users/delete',
        UPDATE_USERINFO: 'users/'
    },
    COMMON: {
        LOAD_DISTRICTS: 'loadDistricts',
        SAVE_USERINFO: 'register',
    }
}
