const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

module.exports = (env = {}) => {
    const prod = env.production ? true : false;
    return {
        mode: prod ? 'production' : 'development',
        entry: path.resolve(__dirname, 'src/index.js'),
        output: {
            path: path.resolve(__dirname, 'dist'),
            filename: 'js/app.bundle.js'
        },
        plugins: [
            new CleanWebpackPlugin(),
            new HtmlWebpackPlugin({
                template: 'public/index.html',
                favicon: 'public/favicon.ico'
            })
        ],
        optimization: {
            minimizer: [new TerserPlugin()],
        },
        devServer: {
            contentBase: path.join(__dirname, 'dist'),
            compress: true,
            port: 9900,
            watchContentBase: true,
        },
        module: {
            rules: [
                {
                    test: /\.js$/,
                    use: 'babel-loader',
                    exclude: [
                        /node_modules/
                    ]
                },
                {
                    test: /.jsx?$/,
                    loader: 'babel-loader',
                    exclude: /node_modules/,
                },
                {
                    test: /\.(s*)css$/, // match any .scss or .css file, 
                    use: [
                        "style-loader",
                        "css-loader",
                        "sass-loader"
                    ]
                },
                {
                    test: /\.(png|jpg|gif)$/,
                    use: [
                        {
                            loader: 'file-loader',
                            options: {
                                outputPath: 'images/',
                                name: '[name][hash].[ext]',
                            },
                        },
                    ],
                },
                {
                    test: /\.(svg)$/,
                    exclude: /fonts/, /* dont want svg fonts from fonts folder to be included */
                    use: [
                        {
                            loader: 'svg-url-loader',
                            options: {
                                noquotes: true,
                            },
                        },
                    ],
                },
                {
                    test: /.(ttf|otf|eot|svg|woff(2)?)(\?[a-z0-9]+)?$/,
                    exclude: /images/,  /* dont want svg images from image folder to be included */
                    use: [
                        {
                            loader: 'file-loader',
                            options: {
                                outputPath: 'fonts/',
                                name: '[name][hash].[ext]',
                            },
                        },
                    ],
                }
            ]
        },
    }
};