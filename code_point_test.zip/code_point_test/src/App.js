import './App.css';
import { Route, Switch, BrowserRouter as Router } from 'react-router-dom'
import CreateEmployeeDetails from './CreateEmployeeDetails';
import ListEmployeeDetails from './ListEmployeeDetails';


function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route path='/list' exact>
            <ListEmployeeDetails />
          </Route>
          <Route path='/create'>
            <CreateEmployeeDetails />
          </Route>
        </Switch>
      </Router>
    </div>
  );
}

export default App;