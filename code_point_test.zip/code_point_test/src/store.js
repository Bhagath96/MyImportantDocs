import employeeReducer from '../src/reducer/reducer.js';
import { createStore, combineReducers, compose } from 'redux';
// import createSagaMiddleware, { END } from 'redux-saga';
// const sagaMiddleware = createSagaMiddleware();

const rootReducer = combineReducers({
    employeeReducer: employeeReducer
});
export default rootReducer;

