const ResData = {
    "success": true,
    "result": [
        {
            "id": "32",
            "name": "City KG 1"
        },
        {
            "id": "2002",
            "name": "City KG 2"
        },
        {
            "id": "15",
            "name": "Grade 1"
        },
        {
            "id": "16",
            "name": "Grade 2"
        },
        {
            "id": "17",
            "name": "Grade 3"
        },
        {
            "id": "18",
            "name": "Grade 4"
        },
        {
            "id": "31",
            "name": "Grade 5"
        },
        {
            "id": "20",
            "name": "Grade 6"
        }
    ],
    "message": "Success"
}
export default ResData;