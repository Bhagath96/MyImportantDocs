import React from 'react'
import { Grid, Paper, Typography, TextField, Button } from '@material-ui/core';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import { Formik } from 'formik';
import * as yup from 'yup';
import * as action from './action.js';
import { useDispatch } from 'react-redux';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';

const CreateEmployeeDetails = (props) => {
    const dispatch = useDispatch();
    const paperStyle = { padding: '30px 20px', width: "1240px", margin: "5px auto" }
    const headerStyle = { margin: 0 }
    const [country, setCountry] = React.useState('');
    const [date, setDate] = React.useState(Date.now);
    const [radioValue, setRadioValue] = React.useState('female');

    const selectDate = (event) => {
        setDate(event.target.value);
    };
    const radioButtonSelection = (event) => {
        setRadioValue(event.target.value);
    };
    const loginValidationSchema = yup.object().shape({

        name: yup
            .string()
            .required('Please enter Name'),
        email: yup
            .string()
            .required("Please enter the required field").email(),
        country: yup
            .string()
            .required('Please select country'),
        DOB: yup
            .date()
            .required('Required'),

    });
    return (
        <Formik
            validationSchema={loginValidationSchema}
            initialValues={{ name: '', email: '', gender: '', DOB: '', country: country }}
            onSubmit={(values) => {
                console.log('hhhhhhhh', values);
                values.country = country;
                values.gender = radioValue;
                values.DOB = date;
                dispatch(action.setSearchTerm(values))
            }}
        >

            {({ handleChange, handleSubmit, values, errors }) => (
                <>
                    {console.log({ errors })}
                    <Grid>
                        <Paper elevation={20} style={paperStyle}>
                            <Grid align='center'>
                                <h2 style={headerStyle}>EMPLOYEE CREATION</h2>
                                <Typography variant='caption' gutterBottom>Please fill this form to create an employee !</Typography>
                            </Grid>
                            <form>
                                <Grid item xs={12}>
                                    <TextField
                                        // value={values.name}
                                        onChange={handleChange('name')}
                                        fullWidth
                                        label='Name'
                                        placeholder="Enter your name" />
                                    <Typography variant="h6" style={{ color: 'red', fontStyle: 'italic' }}>{errors.name}</Typography>
                                </Grid>
                                <Grid item xs={12}>

                                    <TextField
                                        // value={values.email}
                                        onChange={handleChange('email')}
                                        fullWidth
                                        label='Email'
                                        placeholder="Enter your email" />
                                    <Typography variant="h6" style={{ color: 'red', fontStyle: 'italic' }}>{errors.email}</Typography>
                                </Grid>
                                <Grid item xs={12} >
                                    <br></br>
                                    <InputLabel style={{ textAlign: 'left' }}>Country</InputLabel>
                                    <Select
                                        style={{ width: '100%' }}
                                        name='country'
                                        labelId="demo-controlled-open-select-label"
                                        id="demo-controlled-open-select"
                                        value={country}
                                        // onChange={selectionChange}
                                        onChange={e => {
                                            setCountry(e.target?.value);
                                            handleChange('country')(e.target?.value)
                                        }}
                                    >
                                        <MenuItem value="">
                                            <em>None</em>
                                        </MenuItem>
                                        <MenuItem value={'india'}>india</MenuItem>
                                        <MenuItem value={'pakistan'}>pakistan</MenuItem>
                                        <MenuItem value={'tamilNadu'}>tamilNadu</MenuItem>
                                    </Select>
                                    <Typography variant="h6" style={{ color: 'red', fontStyle: 'italic' }}>{errors.country}</Typography>

                                </Grid>
                                <br></br>
                                <Grid container style={{ display: 'flex', flexDirection: 'row' }}>
                                    <Grid item xs={6} >
                                        <TextField
                                            name='DOB'
                                            id="date"
                                            label="DOB"
                                            type="date"
                                            onChange={e => {
                                                setDate(e.target?.value);
                                                handleChange('DOB')(e.target?.value)
                                            }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                        <Typography variant="h6" style={{ color: 'red', fontStyle: 'italic' }}>{errors.DOB}</Typography>

                                    </Grid>
                                    <Grid item xs={6}>
                                        <FormControl component="fieldset">
                                            <FormLabel component="legend">Gender</FormLabel>
                                            <RadioGroup aria-label="gender" name="gender" value={radioValue} onChange={radioButtonSelection}>
                                                <FormControlLabel value="female" control={<Radio />} label="Female" />
                                                <FormControlLabel value="male" control={<Radio />} label="Male" />
                                                <FormControlLabel value="other" control={<Radio />} label="Other" />

                                            </RadioGroup>
                                        </FormControl>
                                    </Grid>
                                </Grid>
                                <Grid item xs={12} ></Grid>
                                <br></br>
                                <br></br>

                                <Grid item xs={12} >
                                    <Button
                                        onClick={handleSubmit}
                                        type='submit'
                                        variant='contained'
                                        color='primary'>
                                        Sign up
                                   </Button>
                                </Grid>
                            </form>
                        </Paper>
                    </Grid>
                </>
            )
            }
        </Formik >
    );
}
export default CreateEmployeeDetails;

