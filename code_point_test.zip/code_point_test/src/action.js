export const TYPES = {
    SET_SEARCH_TERM: 'SET_SEARCH_TERM'
}

export const setSearchTerm = (type, payload) => {

    console.log('action calledddd', type, payload)
    return { type: TYPES.SET_SEARCH_TERM, payload: type }
}