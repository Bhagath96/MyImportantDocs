import { TYPES } from '../action'
export const initialState = {
    term: null
}
const employeeReducer = (state = initialState, action) => {
    switch (action.type) {
        case TYPES.SET_SEARCH_TERM:
            console.log('action', action)
            return {
                ...state,
                term: action.payload
            }

        default:
            return state
    }
}
export default employeeReducer;