import React, { useEffect } from 'react'

import CssBaseline from '@material-ui/core/CssBaseline'
import MaUTable from '@material-ui/core/Table'
import TableBody from '@material-ui/core/TableBody'
import TableCell from '@material-ui/core/TableCell'
import TableHead from '@material-ui/core/TableHead'
import TableRow from '@material-ui/core/TableRow'
import BodyData from './dumyBody.js'
import { useTable } from 'react-table'
import ResData from './responce.js'
import { Button, Typography } from '@material-ui/core'
import { useHistory } from 'react-router-dom'

function Table({ columns, data }) {
    // Use the state and functions returned from useTable to build your UI
    const { getTableProps, headerGroups, rows, prepareRow } = useTable({
        columns,
        data,
    })

    // Render the UI for your table
    return (
        <MaUTable {...getTableProps()}>
            <TableHead>
                {headerGroups.map(headerGroup => (
                    <TableRow {...headerGroup.getHeaderGroupProps()}>
                        {headerGroup.headers.map(column => (
                            <TableCell {...column.getHeaderProps()}>
                                {column.render('Header')}
                            </TableCell>
                        ))}
                    </TableRow>
                ))}
            </TableHead>
            <TableBody>
                {rows.map((row, i) => {
                    prepareRow(row)
                    return (
                        <TableRow {...row.getRowProps()}>
                            {row.cells.map(cell => {
                                return (
                                    <TableCell {...cell.getCellProps()}>
                                        {cell.render('Cell')}
                                    </TableCell>
                                )
                            })}
                        </TableRow>
                    )
                })}
            </TableBody>
        </MaUTable>
    )
}

function ListEmployeeDetails() {
    let tblData = ResData?.result;
    const history = useHistory();
    useEffect(() => {
        fetch('https://1dlkbk98d8.execute-api.ap-south-1.amazonaws.com/Stage/question/class_list,BodyData', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                BodyData
            })
        }).then((response) => response.json())
            .then((responseJson) => {
                console.log(responseJson)
                return responseJson;
            })
            .catch((error) => {
                console.error(error);
            });
    }, [])

    const MoveAddPage = () => {
        history.push('/create')
    }




    const columns = React.useMemo(
        () => [
            {
                Header: 'EMPLOYEE DETAILS',
                columns: [
                    {
                        Header: 'Id',
                        accessor: 'id',
                    },
                    {
                        Header: 'Name',
                        accessor: 'name',
                    },
                ],
            },

        ],
        []
    )

    return (
        <div>
            <div style={{ display: "flex" }}>
                <Button style={{ marginLeft: "auto", backgroundColor: 'green', width: '15%', }} onClick={() => MoveAddPage()}>
                    <Typography variant='h3'> + </Typography>
                </Button>
            </div>
            <CssBaseline />
            { console.log('ResData', ResData)}
            <Table columns={columns} data={tblData} />
        </div >
    )
}

export default ListEmployeeDetails
